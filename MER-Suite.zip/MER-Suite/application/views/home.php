<title>MER Suite | Home</title>

<?php
if ($this->session->userdata('user_info')) {
  $user_info = $this->session->userdata('user_info');
?>
  <?php
  // Assuming $user_info is available and contains user information
  if ($user_info->isFirstLogin == 1) {
    echo "<script>
                let checked = false;

                function checkFirstLogin() {
                    if (!checked) {
                        showChangePasswordModal();
                        checked = true; // Set the flag to true after the first check
                    }
                }

                // Check once every 1 second
                setInterval(checkFirstLogin, 1000);
              </script>";
  }
  ?>
  <!-- Sidebar -->
  <li id="DB-btn" style="background-color: #ffffff;">
    <a id="active" class=" btn btn-block" href="<?php echo site_url('home/index'); ?>">
      <i class="fa-sharp fa-light fa-chart-mixed" style="color: black;"></i>
      <div style="color: black;">Dashboard</div>
    </a>
  </li>
  <?php if ($user_info->AccessType == 'Optometrist' or $user_info->AccessType == 'Secretary') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manage'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>PIR Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manage'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Secretary') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageSec'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manageArchived'); ?>">
        <i class="fa-thin fa-sensor-cloud"></i>
        <div>PIR Archived</div>
      </a>
    </li>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageArchived'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>MER Archived</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Administrator') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manageBackup'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>PIR Backup</div>
      </a>
    </li>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageBackup'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Backup</div>
      </a>
    </li>
    <li id="usersm-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('users/manage'); ?>">
        <i class="fa-duotone fa-users-medical" style="color: #ffffff;"></i>
        <div>Users Management</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="App-Re-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/AppReq'); ?>">
        <i class="fa-duotone fa-clipboard-list-check" style="--fa-secondary-color: #e8e8e8;"></i>
        <div>Approval Request</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Secretary') {  ?>
    <li id="App-Re-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/StatusReq'); ?>">
        <i class="fa-duotone fa-clipboard-list-check"></i>
        <div>Status Request</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist' or $user_info->AccessType == 'Secretary') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/GenerateRecord'); ?>">
        <i class="fa-light fa-table-tree"></i>
        <div>MER Gen-Record</div>
      </a>
    </li>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/GenerateRecord'); ?>">
        <i class="fa-light fa-table-tree"></i>
        <div>PIR Gen-Record</div>
      </a>
    </li>
  <?php
  }

  ?>
  <!-- <li id="Sett-btn">
        <a id="none" class=" btn btn-block" href="#">
            <i class="fa-duotone fa-gear"></i>
            <div>Settings</div>
        </a>
    </li> -->
  <li id="Sgn-Out-btn">
    <a id="none" class=" btn btn-block" href="<?php echo site_url('login/logout') ?>">
      <!-- <i class="fa-duotone fa-chevrons-left" style="--fa-primary-color: #b9a7a7; --fa-primary-opacity: 0.5; --fa-secondary-color: #c5b4b4; --fa-secondary-opacity: 01;"></i> -->
      <i id="signout-i" class="fa-duotone fa-arrow-right-from-bracket fa-rotate-180" style="color: #e6e6e6;"></i>
      <div>Sign Out</div>
    </a>
  </li>

  </div>

  <!-- Toggle Button -->
  <div class="toggle-btn" onclick="toggleSidebar()">
    <span class="fas fa-bars fa-2x"></span>
  </div>

  <!-- Content Area -->
  <div class="content">


    <!-- Button for opening new window -->

    <!-- <div class="container text-center mt-5">
              <h1>Responsive Page with Button</h1>
              <p>This is a responsive Bootstrap 4 webpage.</p>
              <button class="btn btn-primary" onclick="openNewWindow()">Open New Window</button>
             </div> -->
    <!-- ---------------------------- -->



    <!-- <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#events">Events</a></li>
            <li><a href="#team">Team</a></li>
            <li class="dropdown">
            <a href="#works" class="dropdown-toggle"  data-toggle="dropdown">Works <span class="caret"></span></a>
          <ul class="dropdown-menu animated fadeInLeft" role="menu">
           <div class="dropdown-header">Dropdown heading</div>
           <li><a href="#pictures">Pictures</a></li>
           <li><a href="#videos">Videeos</a></li>
           <li><a href="#books">Books</a></li>
           <li><a href="#art">Art</a></li>
           <li><a href="#awards">Awards</a></li>
           </ul>
           </li>
           <li><a href="#services">Services</a></li>
           <li><a href="#contact">Contact</a></li>
           <li><a href="#followme">Follow me</a></li> -->


    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->

    <div class="container-fluid">
      <!-- Right slide window -->
      <div class="row">

        <div class="container-fluid  text-md-right ">
          <div class="useri-admn-btn container-fluid ">
            <div class="col-md-12 ">

              <!-- Button add modal -->
              <!-- <div class="container text-md-right mt-1">
                          <div class="row">
                            <div class="col-md-12"> -->
              <!-- Button add modal -->

              <!-- </div>
                          </div>
                        </div> -->



              <!--  Admin Dropdown  -->
              <button type="button" id="useradmbtn" class="btn dropdown-toggle col-md-13 text-md-right" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?= base_url('image/employees_image/' . $user_info->Image); ?>" width="45" height="45" class="rounded-circle"><?= $user_info->Name ?>
              </button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo site_url('users/myprofile') ?>">Profile</a>
                <a class="dropdown-item" href="#" onclick="showChangePassword()">Change Password</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo site_url('login/logout') ?>">Sign Out</a>
              </div>
            </div>
          </div>
        </div>

        <div class="container-fluid">
          <div class="row text-center">
            <div class="userm-txt">
              <h1 id="helo-lbl">Hello <?= $user_info->Name ?>!</h1>
            </div>
          </div>
        <?php
      }

        ?>
        <?php if ($user_info->AccessType == 'Administrator') {  ?>
          <div id="bg-lightblue" class="container-fluid bg-lightblue">
            <div class="container-fluid text-left">
              <h2>Total of Users
                <p class="pl-5"><?php
                                if (isset($users)) {
                                  echo sizeof($users);
                                } else {
                                  echo 0;
                                } ?>
                </p>
              </h2>
            </div>
            <div class="row">

              <!-- First blue box -->
              <div class="col-sm-6 bg-blue mb-3">
                <div id="con1" class="container-fluid text-center pt-5">
                  <h3>New Users</h3>
                  <h3><?php
                      if (isset($newusers)) {
                        echo sizeof($newusers);
                      } else {
                        echo 0;
                      } ?>
                  </h3>
                </div>
              </div>

              <!-- Second blue box -->
              <div class="col-sm-6 bg-blue mb-3">
                <div id="con2" class="container-fluid text-center pt-5">
                  <h3>Old Users</h3>
                  <h3><?php
                      if (isset($oldusers)) {
                        echo sizeof($oldusers);
                      } else {
                        echo 0;
                      } ?></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>



      <!-- ----------------------------- -->

      <!-- <div class="red-arrow">               
                    <i id="red-arrow" class="fa-regular fa-arrow-trend-down"></i>                    
                </div> -->

      <!-- System Performance -->


    </div>

    <!-- <div class="container-fluid mt-5 pl-4">
      <div class="sys-per">
        <div class="sys-black">System Performance</div>
      </div>
      <div class="row">
        <div class="col-sm-3">
          <div class="lightblue-egg">
            <div class="act-logs">Activity logs</div>
            <div class="pie animate" style="--p:67;--c:#2ebe0e"> 67%</div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="yellow-egg">
            <div class="sto-used">Storage Used</div>
            <div class="pie animate" style="--p:46;--c:#3211c5"> 46%</div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="blue-egg">
            <div class="sto-avail">Storage Availability</div>
            <div class="pie animate" style="--p:15;--c:#c51111"> 15%</div>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="red-egg">
            <div class="security">Security</div>
            <div class="pie animate" style="--p:67;--c:#00ccd3"> 67%</div>
          </div>
        </div>
      </div> -->
    <div class="container">
      <div class="row">
        <div class="col-md-2 mt-5">
          <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" id="intervalDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span id="selectedInterval">Weekly</span>
            </button>
            <div class="dropdown-menu" aria-labelledby="intervalDropdown">
              <a class="dropdown-item" href="#" onclick="updateData('weekly')">Weekly</a>
              <a class="dropdown-item" href="#" onclick="updateData('monthly')">Monthly</a>
              <a class="dropdown-item" href="#" onclick="updateData('yearly')">Yearly</a>
            </div>
          </div>
        </div>
        <div class="col-md-10 mt-5">
          <div class="chart-container">
            <canvas id="weeklyChart"></canvas>
          </div>
        </div>
      </div>
    </div>




    <!-----------  PIE CHARTS  ----------->






  </div>
<?php
        }

?>

<?php {

?>
  <?php if ($user_info->AccessType == 'Optometrist' or $user_info->AccessType == 'Secretary') {  ?>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-7">
          <div id="bg-lightblue" class="container-fluid bg-lightblue">
            <div class="container-fluid text-left">
              <h2>Total of Patients
                <p class="pl-5"><?php
                                if (isset($pasyentes)) {
                                  echo sizeof($pasyentes);
                                } else {
                                  echo 0;
                                } ?></p>
              </h2>
            </div>


            <div class="row">

              <!-- First blue box -->
              <div class="col-sm-6 bg-blue mb-3">
                <div id="con1" class="container-fluid text-center pt-5">
                  <h3>New Patients</h3>
                  <h3><?php
                      if (isset($newpasyentes)) {
                        echo sizeof($newpasyentes);
                      } else {
                        echo 0;
                      } ?></h3>
                </div>
              </div>

              <div class="col-sm-6 bg-blue mb-3">
                <div id="con2" class="container-fluid text-center pt-5">
                  <h3>Old Patients</h3>
                  <h3><?php
                      if (isset($oldpasyentes)) {
                        echo sizeof($oldpasyentes);
                      } else {
                        echo 0;
                      } ?></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php if ($user_info->AccessType == 'Optometrist') {  ?>
          <div class="col-sm-5">
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Approval Queue</th>
                    <th id="hidetbody">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th id="hidetbody">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th>&nbsp;&nbsp;Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($items)) : ?>
                    <tr>
                      <td colspan="4" style="font-size: 50px; font-style:italic; color: grey;">EMPTY</td>
                    </tr>
                  <?php else : ?>
                    <?php foreach ($items as $item) : ?>
                      <tr>
                        <td>
                          <div class="outer-circle">
                            <div class="inner-circle">
                              <i class="fas fa-user"></i>
                            </div>
                          </div>
                        </td>
                        <td class="first-que"><?= $item['PatientName'] ?></td>
                        <td class="first-date"><?= date('F j, Y', strtotime($item['DateCreated'])) ?></td>
                        <td>
                          <a href="<?php echo site_url('mer/AppReq'); ?>" id="today-btn" class="btn btn-warning ripple-btn">VIEW</a>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php
        }

        ?>
        <?php if ($user_info->AccessType == 'Secretary') {  ?>
          <div class="col-sm-5">
            <div class="table-responsive">
              <table>
                <thead>
                  <tr>
                    <th>Approval Queue</th>
                    <th id="hidetbody">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                    <th id="hidetbody">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if (empty($items)) : ?>
                    <tr>
                      <td colspan="3" style="font-size: 50px; font-style:italic; color: grey;">EMPTY</td>
                    </tr>
                  <?php else : ?>
                    <?php foreach ($items as $item) : ?>
                      <tr>
                        <td>
                          <div class="outer-circle">
                            <div class="inner-circle">
                              <i class="fas fa-user"></i>
                            </div>
                          </div>
                        </td>
                        <td class="first-que"><?= $item['PatientName'] ?></td>
                        <td class="first-date"><?= date('F j, Y', strtotime($item['DateCreated'])) ?></td>
                      </tr>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php
        }

        ?>
      </div>


    </div>
    </div>
    </div>
  <?php
  }

  ?>




  </div>
<?php   } ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script type="text/javascript">
  function updateData(interval) {
    $.ajax({
      url: "<?php echo base_url('home/get_user_data'); ?>/" + interval,
      type: "GET",
      dataType: "json",
      success: function(data) {
        let labels = [];
        let values = [];

        if (interval === 'weekly' || interval === 'monthly' || interval === 'yearly') {
          data.forEach(function(item) {
            labels.push(item.Date);
            values.push(item.Count);
          });

          if (interval === 'weekly') {
            weeklyChart.options.scales.x.title.text = "Days of the Week";
            document.getElementById('selectedInterval').textContent = 'Weekly';
          } else if (interval === 'monthly') {
            weeklyChart.options.scales.x.title.text = "Months of the Year";
            document.getElementById('selectedInterval').textContent = 'Monthly';
          } else if (interval === 'yearly') {
            weeklyChart.options.scales.x.title.text = "Years";
            document.getElementById('selectedInterval').textContent = 'Yearly';
          }
        }

        weeklyChart.data.labels = labels;
        weeklyChart.data.datasets[0].data = values;
        weeklyChart.update();
      },
      error: function(xhr, status, error) {
        console.error(xhr.responseText);
      }
    });
  }
  const ctx = document.getElementById("weeklyChart").getContext("2d");

  const weeklyChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Weekly Data",
        data: [],
        backgroundColor: "rgba(75, 192, 192, 0.2)",
        borderColor: "royalblue",
        borderWidth: 2,
        pointRadius: 5,
        pointBackgroundColor: "royalblue",
      }],
    },
    options: {
      scales: {
        x: {
          display: true,
          title: {
            display: true,
            text: "Days of the Week",
          },
        },
        y: {
          display: true,
          title: {
            display: true,
            text: "Number of Entry Data",
          },
          suggestedMin: 0, // Set the minimum value of the y-axis
          suggestedMax: 10, // Set the maximum value of the y-axis (adjust as needed)
          stepSize: 1, // Set the step size to 1 to ensure whole numbers
        },
      },
      plugins: {
        legend: {
          display: false,
        },
        animation: {
          tension: {
            duration: 1000,
            easing: "linear",
            from: 1,
            to: 0,
          },
        },
      },
    },
  });

  // Call updateData function with 'weekly' interval to fetch and update the chart with weekly data.
  updateData('weekly');
</script>