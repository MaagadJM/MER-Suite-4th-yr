<title>MER Suite | Profile</title>

<?php
if ($this->session->userdata('user_info')) {
  $user_info = $this->session->userdata('user_info');
?>
  <?php
  // Assuming $user_info is available and contains user information
  if ($user_info->isFirstLogin == 1) {
    echo "<script>
                let checked = false;

                function checkFirstLogin() {
                    if (!checked) {
                        showChangePasswordModal();
                        checked = true; // Set the flag to true after the first check
                    }
                }

                // Check once every 1 second
                setInterval(checkFirstLogin, 1000);
              </script>";
  }
  ?>
  <!-- Sidebar -->
  <li id="DB-btn" style="background-color: #ffffff;">
    <a id="active" class=" btn btn-block" href="<?php echo site_url('home/index'); ?>">
      <i class="fa-sharp fa-light fa-chart-mixed" style="color: black;"></i>
      <div style="color: black;">Dashboard</div>
    </a>
  </li>
  <?php if ($user_info->AccessType == 'Optometrist' or $user_info->AccessType == 'Secretary') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manage'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>PIR Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manage'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Secretary') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageSec'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Repository</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manageArchived'); ?>">
        <i class="fa-thin fa-sensor-cloud"></i>
        <div>PIR Archived</div>
      </a>
    </li>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageArchived'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>MER Archived</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Administrator') {  ?>
    <li id="PIR-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/manageBackup'); ?>">
        <i class="fa-thin fa-sensor-cloud" style="color: #ffffff;"></i>
        <div>PIR Backup</div>
      </a>
    </li>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/manageBackup'); ?>">
        <i class="fa-light fa-table-tree" style="color: #ffffff;"></i>
        <div>MER Backup</div>
      </a>
    </li>
    <li id="usersm-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('users/manage'); ?>">
        <i class="fa-duotone fa-users-medical" style="color: #ffffff;"></i>
        <div>Users Management</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist') {  ?>
    <li id="App-Re-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/AppReq'); ?>">
        <i class="fa-duotone fa-clipboard-list-check" style="--fa-secondary-color: #e8e8e8;"></i>
        <div>Approval Request</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Secretary') {  ?>
    <li id="App-Re-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/StatusReq'); ?>">
        <i class="fa-duotone fa-clipboard-list-check"></i>
        <div>Status Request</div>
      </a>
    </li>
  <?php
  }

  ?>
  <?php if ($user_info->AccessType == 'Optometrist' or $user_info->AccessType == 'Secretary') {  ?>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('mer/GenerateRecord'); ?>">
        <i class="fa-light fa-table-tree"></i>
        <div>MER Gen-Record</div>
      </a>
    </li>
    <li id="MER-R-btn">
      <a id="none" class=" btn btn-block" href="<?php echo site_url('pasyente/GenerateRecord'); ?>">
        <i class="fa-light fa-table-tree"></i>
        <div>PIR Gen-Record</div>
      </a>
    </li>
  <?php
  }

  ?>
  <!-- <li id="Sett-btn">
        <a id="none" class=" btn btn-block" href="#">
            <i class="fa-duotone fa-gear"></i>
            <div>Settings</div>
        </a>
    </li> -->
  <li id="Sgn-Out-btn">
    <a id="none" class=" btn btn-block" href="<?php echo site_url('login/logout') ?>">
      <!-- <i class="fa-duotone fa-chevrons-left" style="--fa-primary-color: #b9a7a7; --fa-primary-opacity: 0.5; --fa-secondary-color: #c5b4b4; --fa-secondary-opacity: 01;"></i> -->
      <i id="signout-i" class="fa-duotone fa-arrow-right-from-bracket fa-rotate-180" style="color: #e6e6e6;"></i>
      <div>Sign Out</div>
    </a>
  </li>

  </div>

  <!-- Toggle Button -->
  <div class="toggle-btn" onclick="toggleSidebar()">
    <span class="fas fa-bars fa-2x"></span>
  </div>

  <!-- Content Area -->
  <div class="content">


    <!-- Button for opening new window -->

    <!-- <div class="container text-center mt-5">
              <h1>Responsive Page with Button</h1>
              <p>This is a responsive Bootstrap 4 webpage.</p>
              <button class="btn btn-primary" onclick="openNewWindow()">Open New Window</button>
             </div> -->
    <!-- ---------------------------- -->



    <!-- <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#events">Events</a></li>
            <li><a href="#team">Team</a></li>
            <li class="dropdown">
            <a href="#works" class="dropdown-toggle"  data-toggle="dropdown">Works <span class="caret"></span></a>
          <ul class="dropdown-menu animated fadeInLeft" role="menu">
           <div class="dropdown-header">Dropdown heading</div>
           <li><a href="#pictures">Pictures</a></li>
           <li><a href="#videos">Videeos</a></li>
           <li><a href="#books">Books</a></li>
           <li><a href="#art">Art</a></li>
           <li><a href="#awards">Awards</a></li>
           </ul>
           </li>
           <li><a href="#services">Services</a></li>
           <li><a href="#contact">Contact</a></li>
           <li><a href="#followme">Follow me</a></li> -->


    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->

    <div class="container-fluid">
      <!-- Right slide window -->
      <div class="row">

        <div class="container-fluid  text-md-right ">
          <div class="useri-admn-btn">
            <div class="col-md-12 ">

              <!-- Button add modal -->
              <!-- <div class="container text-md-right mt-1">
                          <div class="row">
                            <div class="col-md-12"> -->
              <!-- Button add modal -->

              <!-- </div>
                          </div>
                        </div> -->



              <!--  Admin Dropdown  -->
              <button type="button" id="useradmbtn" class="btn dropdown-toggle col-md-13 text-md-right" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img src="<?= base_url('image/employees_image/' . $user_info->Image); ?>" width="45" height="45" class="rounded-circle"><?= $user_info->Name ?>
              </button>
              <div class="dropdown-menu">
                <a class="dropdown-item" href="<?php echo site_url('users/myprofile') ?>">Profile</a>
                <a class="dropdown-item" href="#" onclick="showChangePassword()">Change Password</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="<?php echo site_url('login/logout') ?>">Sign Out</a>
              </div>
            </div>
          </div>
        </div>

        <div class="text-left">
          <div class="userm-txt">
            Edit Profile
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <form id="updatePForm" enctype="multipart/form-data">
          <div class="row">

            <!-- --------------------- Choose profile form ------------------ -->
            <div class="col-md-4 mb-3">

              <div id="left-frm" class="card">
                <div class="card-body">
                  <div class="text-center">
                    <img src="<?= base_url('image/employees_image/' . $user_info->Image); ?>" alt="Profile Picture" class="img-fluid rounded-circle mb-3" id="profileImage">
                    <div class="custom-file">
                      <input type="file" class="form-control-file" id="Image" name="Image" aria-describedby="inputGroupFileAddon01" onchange="displayFileName()">
                    </div>
                    <div class="form-group mt-4">
                      <div id="descript-txt" class="card">
                        <div id="antioverflow" class="card-body">
                          <p>Upload a new photo. Larger image will be resized automatically.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- --------------------- Choose profile form end ------------------ -->

            <!-- --------------------- User Info form ------------------ -->
            <div class="col-md-8">
              <div id="usr-info" class="card">
                <div class="card-body">
                  <!-- Header -->
                  <div class="form-row justify-content-center mb-4">
                    <div class="col-md-12">
                      <h2 class="">User info</h2>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="fullname">Full Name</label>
                      <input type="name" class="form-control" id="Fullname" name="Fullname" value="<?= $user_info->Name ?>" readonly>
                    </div>
                    <div class="form-group col-md-6">
                      <label for="username">Username</label>
                      <input type="text" class="form-control" id="Username" name="Username" value="<?= $user_info->Username ?>" readonly>
                    </div>
                  </div>

                  <div class="form-row ">
                    <div class="form-group col-md-6">
                      <label for="email">Email</label>
                      <input type="email" class="form-control" id="Email" name="Email" value="<?= $user_info->Email ?>">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="Date">DateCreated</label>
                      <input type="text" class="form-control" id="date" name="date" value="<?= date('F j, Y', strtotime($user_info->DateCreated)) ?>" readonly>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="password">Password</label>
                      <input type="password" class="form-control" id="Password" name="Password">
                    </div>
                    <div class="form-group col-md-6">
                      <label for="confirmPassword">Confirm Password</label>
                      <input type="password" class="form-control" id="ConfirmPassword" name="ConfirmPassword">
                    </div>
                  </div>
                  <!-- --------------------- User Info form end ------------------ -->

                  <div class="form-row justify-content-end mr-1 mt-4">
                    <button type="submit" id="updt-btn" class="btn btn-primary">Update</button>
                  </div>

                </div>
              </div>
            </div>
        </form>
      </div>
    </div>

    <!-- --------------------- User Info form ------------------ -->

  </div>


  </div>
<?php
}

?>




</div>